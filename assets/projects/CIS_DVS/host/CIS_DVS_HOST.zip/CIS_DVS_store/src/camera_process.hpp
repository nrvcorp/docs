#include <opencv2/opencv.hpp>
#include <iostream>
#include <assert.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <sched.h>
#include <fstream>

#include <condition_variable>
#include "dma_utils.hpp"
#include "config.hpp"
#include "image_util.hpp"

using namespace cv;
using namespace std;

struct ThreadArgs {
    pcie_trans *trans;
    char *dvs_buffer_1;
    char *dvs_buffer_2;
};

void CIS_only_display_stream(pcie_trans *trans);
void DVS_only_display_stream(pcie_trans *trans);
void DVS_only_check_frame(pcie_trans *trans);
void CIS_DVS_stream(pcie_trans *trans);
void DVS_threading(pcie_trans *trans);
void *DVS_crop_coord(void *args);
void CIS_DVS_bbox_stream(pcie_trans *trans);