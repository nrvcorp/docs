#include <iostream>

#include <opencv2/opencv.hpp>
#include "image_util.hpp"

// Function to convert 2-bit image data to 8-bit
void convert2BitTo8Bit(char *src, uint8_t *dst, int width, int height)
{
    int numPixels = width * height;
    for (int i = 0; i < numPixels; ++i)
    {
        int byteIndex = i / 4;
        int bitOffset = (i % 4) * 2;
        uint8_t pixel = (src[byteIndex] >> bitOffset) & 0x03; // Extract 2 bits
        // dst[i] = pixel * 85;                                  // Map 2-bit value to 8-bit value (0, 85, 170, 255)
        dst[i] = (pixel == 0) ? 128 : // no event
                     (pixel == 1) ? 255
                                  : // on event
                     (pixel == 2) ? 0
                                  : // off event
                     0;
    }
}

// Function to convert 2-bit image data to 8-bit
void convert2BitTo8Bit_accum(char *src, uint8_t *dst, int width, int height)
{
    int numPixels = width * height;
    for (int i = 0; i < numPixels; ++i)
    {
        int byteIndex = i / 4;
        int bitOffset = (i % 4) * 2;
        uint8_t pixel = (src[byteIndex] >> bitOffset) & 0x03; // Extract 2 bits
        if (pixel == 1)
        {
            dst[i] = 255;
        }
        else if (pixel == 2)
        {
            dst[i] = 0;
        }
    }
}

void convert2BitToBGR_accum(char *src, uint8_t *dst, int width, int height)
{
    int numPixels = width * height;
    for (int i = 0; i < numPixels; i++)
    {
        int byteIndex = i / 4;
        int bitOffset = (i % 4) * 2;
        int pixel = (src[byteIndex] >> bitOffset) & 0x03;
        if (pixel == 1)
        {
            // red
            dst[i * 3] = (dst[i * 3] < 40) ? 0 : (dst[i * 3] - 40);
            dst[i * 3 + 2] = (dst[i * 3 + 2] + 40 > 255) ? 255 : (dst[i * 3 + 2] + 40);
        }
        else if (pixel == 2)
        {
            // blue
            dst[i * 3] = (dst[i * 3] + 40 > 255) ? 255 : (dst[i * 3] + 40);
            dst[i * 3 + 2] = (dst[i * 3 + 2] < 40) ? 0 : (dst[i * 3 + 2] - 40);
        }
    }
}

int event_accum(char *src, int *x_count, int *y_count, int width, int height)
{
    int sum = 0;
    for (int h = 0; h < height; h++)
    {
        for (int byteIndex = 0; byteIndex < (width >> 2); ++byteIndex)
        {
            for (int bitOffset = 0; bitOffset < 8; bitOffset += 2)
            {
                uint8_t pixel = (src[h * (width >> 2) + byteIndex] >> bitOffset) & 0x03; // Extract 2 bits
                if (pixel != 0)
                {
                    x_count[(byteIndex << 2) | (bitOffset >> 1)]++;
                    y_count[h]++;
                    sum++;
                }
            }
        }
    }
    return sum;
}

int event_roi(int *x_count, int *y_count, int width, int height, int sum, int threshold, int roi_min_size, float inflation_ratio, bbox *bounding_box)
{
    int x_avg = sum / width;
    int x_thresh_count = 0;
    int x_min = 0, x_max = 0;
    for (int w = 0; w < width; w++)
    {
        if (x_count[w] > x_avg)
        {
            x_thresh_count++;
            if (x_thresh_count >= threshold)
            {
                if (x_min == 0)
                {
                    x_min = w - threshold + 1;
                    x_max = w;
                }
                else if (w > x_max)
                {
                    x_max = w;
                }
            }
        }
        else
        {
            x_thresh_count = 0;
        }
    }

    int y_avg = sum / height;
    int y_thresh_count = 0;
    int y_min = 0, y_max = 0;
    for (int h = 0; h < height; h++)
    {
        if (y_count[h] > y_avg)
        {
            y_thresh_count++;
            if (y_thresh_count >= threshold)
            {
                if (y_min == 0)
                {
                    y_min = h - threshold + 1;
                    y_max = h;
                }
                else if (h > y_max)
                {
                    y_max = h;
                }
            }
        }
    }
    int inflated_size = (int)(inflation_ratio * (x_max - x_min));
    if(inflated_size > height){
        inflated_size = height;
    }else if(inflated_size < roi_min_size){
        inflated_size = roi_min_size;
    }
    int min_offset = (inflated_size - (x_max - x_min)) / 2;
    if(x_min - min_offset < 0){
        bounding_box->lx = 0;
        bounding_box->hx = inflated_size - 1;
    }else if(y_min + inflated_size - min_offset >= width){
        bounding_box->hx = width;
        bounding_box->lx = width - inflated_size + 1;
    }else{
        bounding_box->lx = x_min - min_offset;
        bounding_box->hx = x_min - min_offset + inflated_size - 1 ;
    }

    if(y_min - min_offset < 0){
        bounding_box->ly = 0;
        bounding_box->hy = inflated_size - 1;
    }else if(y_min + inflated_size - min_offset >= height){
        bounding_box->hy = height;
        bounding_box->ly = height - inflated_size + 1;
    }else{
        bounding_box->ly = y_min - min_offset;
        bounding_box->hy = y_min - min_offset + inflated_size - 1;
    }
    return (x_min != 0 ||y_min!=0); 
}