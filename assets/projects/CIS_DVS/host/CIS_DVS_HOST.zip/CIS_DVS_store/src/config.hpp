#ifndef CONFIG_H
#define CONFIG_H

// <Additional configuraitons>
// ANSI escape codes for text colors
#define ANSI_COLOR_RED "\x1b[31m"
#define ANSI_COLOR_GREEN "\x1b[32m"
#define ANSI_COLOR_YELLOW "\x1b[33m"
#define ANSI_COLOR_BLUE "\x1b[34m"
#define ANSI_COLOR_MAGENTA "\x1b[35m"
#define ANSI_COLOR_CYAN "\x1b[36m"
#define ANSI_COLOR_RESET "\x1b[0m"

// #define DEBUG

#define DDR_BASEADDR 0x10000000

/******************* CIS Setting **********************************/
#define CIS_FRAME_W 1920
#define CIS_FRAME_H 1080
#define CIS_BUFFER_NUM 5
#define CIS_FRAME_SIZE (CIS_FRAME_W * CIS_FRAME_H * 3)
#define CIS_FRAME_RDY_BASEADDR (DDR_BASEADDR + 0x1000000)
#define CIS_FRAME_BASEADDR (DDR_BASEADDR + 0x10000000)

/******************* DVS Setting **********************************/
#define DVS_FRAME_W 960
#define DVS_FRAME_H 720
#define FRAME_HEADER_BYTES 8
#define DVS_BUFFER_NUM 100
#define DVS_FRAME_SIZE ((DVS_FRAME_W * DVS_FRAME_H * 2) / 8 + FRAME_HEADER_BYTES)
#define DVS_FRAME_RDY_BASEADDR (DDR_BASEADDR + 0x2000000)
#define DVS_FRAME_BASEADDR (DDR_BASEADDR + 0x30000000)

/******************* DISPLAY Setting ******************************/
#define DVS_FPS 2000
#define DISPLAY_FPS 60
#define SAVE_FPS 20
#define ROI_THRESH 7
#define ROI_INFLATION (float)(1.4)
#define ROI_MIN_SIZE 416
#define CIS_DVS_OFFSET_X 720
#define CIS_DVS_OFFSET_Y 330
#define CIS_DVS_SCALE_X 0.35
#define CIS_DVS_SCALE_Y 0.35
#define DMA_BUFFER_GRP_NUM (DVS_FPS / DISPLAY_FPS)
#define waitkey_delay (1000 / DISPLAY_FPS)

/******************* PCIE Setting ******************************/
#define H2C_DEVICE_DVS "/dev/xdma0_h2c_0"
#define C2H_DEVICE_DVS "/dev/xdma0_c2h_0"
#define H2C_DEVICE_CIS "/dev/xdma0_h2c_1"
#define C2H_DEVICE_CIS "/dev/xdma0_c2h_1"
#define REG_DEVICE "/dev/xdma0_xvc"
#define USER_DEVICE "/dev/xdma0_user"
#define MAP_SIZE (32 * 1024UL)
// #define MAP_MASK (MAP_SIZE - 1)
// #define COUNT_DEFAULT (1)

//--------------------------------------------------------
// Modes for Streaming code
// Mode 0: CIS_ONLY_DISPLAY
// Mode 1: DVS_ONLY_DISPLAY
// Mode 2: CIS_DVS
//--------------------------------------------------------
typedef enum
{
    CIS_ONLY_DISPLAY,
    DVS_ONLY_DISPLAY,
    DVS_ONLY_CHECK,
    CIS_DVS,
    DVS_STORE,
    DVS_ROI,
    CIS_DVS_BBOX
} MODE;

typedef struct
{
    char *h2c_device_cis;
    char *c2h_device_cis;
    char *h2c_device_dvs;
    char *c2h_device_dvs;
    char *reg_device;
    char *user_device;
    int h2c_fd_cis;
    int c2h_fd_cis;
    int h2c_fd_dvs;
    int c2h_fd_dvs;
    int reg_fd;
    int user_fd;
    void *user_base;
} pcie_trans;

int configure(pcie_trans *trans);

#endif