#ifndef __IMAGE_UTIL_HPP
#define __IMAGE_UTIL_HPP

void convert2BitTo8Bit(char *src, uint8_t *dst, int width, int height);
void convert2BitTo8Bit_accum(char *src, uint8_t *dst, int width, int height);
void convert2BitToBGR_accum(char *src, uint8_t *dst, int width, int height);

typedef struct
{
    int lx;
    int ly;
    int hx;
    int hy;
} bbox;

int event_accum(char *src, int *x_count, int *y_count, int width, int height);
int event_roi(int *x_count, int *y_count, int width, int height, int sum, int threshold, int roi_min_size,float inflation_ratio, bbox *bounding_box);

#endif