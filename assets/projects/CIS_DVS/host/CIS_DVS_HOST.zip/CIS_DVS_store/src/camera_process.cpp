#include "camera_process.hpp"


pthread_mutex_t display_mutex = PTHREAD_MUTEX_INITIALIZER;


// Mutexes and condition variables
pthread_mutex_t dvs_buffer_1_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_mutex_t dvs_buffer_2_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t dvs_buffer_cond = PTHREAD_COND_INITIALIZER;


// Buffer state flags
bool buffer_1_ready = false;
bool buffer_2_ready = false;

pthread_mutex_t bbox_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t bbox_cond = PTHREAD_COND_INITIALIZER;
bbox Bbox;
bool bbox_ready = false;



// int main()
// {
//     pcie_trans pcie_trans_t;

//     printf(ANSI_COLOR_BLUE);
//     printf("************************************************\r\n");
//     printf("*******                              ***********\r\n");
//     printf("*******  CIS, DVS Video Application  ***********\r\n");
//     printf("*******                              ***********\r\n");
//     printf("************************************************\r\n");
//     printf(ANSI_COLOR_RESET);

//     int mode = DVS_STORE;

//     configure(&pcie_trans_t);
//     printf("configure success\r\n");

//     switch (mode)
//     {
//     case CIS_ONLY_DISPLAY:
//         CIS_only_display_stream(&pcie_trans_t);
//         break;
//     case DVS_ONLY_DISPLAY:
//         DVS_only_display_stream(&pcie_trans_t);
//         break;
//     case DVS_ONLY_CHECK:
//         printf("currently on DVS_ONLY_CHECK mode\r\n");
//         DVS_only_check_frame(&pcie_trans_t);
//         break;
//     case CIS_DVS:
//         printf("currently on CIS, DVS display mode\r\n");
//         CIS_DVS_stream(&pcie_trans_t);
//         break;
//     case DVS_STORE:
//         printf("currently on DVS store mode\r\n");
//         DVS_threading(&pcie_trans_t);
//         break;
//     case DVS_CROP_COORD:
//         printf("currently on DVS ROI detection mode\r\n");
//         DVS_crop_coord(&pcie_trans_t);
//         break;
//     default:
//         break;
//     }
//     return 0;
// }

void CIS_only_display_stream(pcie_trans *trans)
{
    uintptr_t cis_buffer_rdy_addr[CIS_BUFFER_NUM];
    uintptr_t cis_buffer_addr[CIS_BUFFER_NUM];
    int cis_rd_ptr = 0;
    char *cis_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *cis_buffer_done = (char *)malloc(1 * sizeof(char));
    cis_buffer_done[0] = 0x00;

    for (int i = 0; i < CIS_BUFFER_NUM; i++)
    {
        cis_buffer_rdy_addr[i] = CIS_FRAME_RDY_BASEADDR + i;
        cis_buffer_addr[i] = CIS_FRAME_BASEADDR + ((CIS_FRAME_SIZE)*i);
    }

    while (1)
    {
        Mat CIS_frame = Mat::zeros(CIS_FRAME_H, CIS_FRAME_W, CV_8UC3);
        while (1)
        {
            read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, cis_buffer_rdy, 1, cis_buffer_rdy_addr[cis_rd_ptr]);
            if ((cis_buffer_rdy[0] & 0x01) == 1)
            { // buffer ready
                break;
            }
        }

        read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, (char *)CIS_frame.data, CIS_FRAME_SIZE, cis_buffer_addr[cis_rd_ptr]);
        write_from_buffer(trans->h2c_device_cis, trans->h2c_fd_cis, cis_buffer_done, 1, cis_buffer_rdy_addr[cis_rd_ptr]);

        imshow("CIS camera", CIS_frame);

        if (waitKey(1) == 27) // Exit if ESC is pressed
            break;
    }
}

void DVS_only_display_stream(pcie_trans *trans)
{
    uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    int dvs_rd_ptr = 0;
    char *dvs_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    for (int i = 0; i < DVS_BUFFER_NUM; i++)
    {
        dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
        dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    }

    int dvs_frame_grp_num = 0;
    while (1)
    {
        Mat DVS_frame = Mat::zeros(DVS_FRAME_H, DVS_FRAME_W, CV_8UC1);

        for (int dvs_frame_grp_num = 0; dvs_frame_grp_num < 20; dvs_frame_grp_num++)
        {
            while (1)
            {
                read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);
                if ((dvs_buffer_rdy[0] & 0x01) == 1)
                { // buffer ready
                    break;
                }
            }

            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr[dvs_rd_ptr]);
            write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);

            if (dvs_frame_grp_num == 0)
            {
                convert2BitTo8Bit(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            else
            {
                convert2BitTo8Bit_accum(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }

            if (dvs_rd_ptr == DVS_BUFFER_NUM - 1)
            {
                dvs_rd_ptr = 0;
            }
            else
            {
                dvs_rd_ptr++;
            }
        }

        imshow("DVS camera", DVS_frame);
        if (waitKey(1) == 27) // Exit if ESC is pressed
            break;
    }
}

void DVS_only_check_frame(pcie_trans *trans)
{
    uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    int dvs_rd_ptr = 0;
    char *dvs_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    for (int i = 0; i < DVS_BUFFER_NUM; i++)
    {
        dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
        dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    }

    int prev_frame_num;
    int prev_timestamp;
    int check_init = 0;
    int error_num = 0;
    while (1)
    {
        if (check_init < 1000)
        {
            check_init++;
        }

        read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);
        if ((dvs_buffer_rdy[0] & 0x01) == 1)
        { // buffer ready
            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr[dvs_rd_ptr]);
            write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);

            int frame_num = ((static_cast<unsigned char>(dvs_buffer[7]) << 24) |
                             (static_cast<unsigned char>(dvs_buffer[6]) << 16) |
                             (static_cast<unsigned char>(dvs_buffer[5]) << 8) |
                             static_cast<unsigned char>(dvs_buffer[4]));
            uint32_t timestamp = ((static_cast<unsigned char>(dvs_buffer[3]) << 24) |
                                  (static_cast<unsigned char>(dvs_buffer[2]) << 16) |
                                  (static_cast<unsigned char>(dvs_buffer[1]) << 8) |
                                  static_cast<unsigned char>(dvs_buffer[0]));
            // cout << "frame_pointer value: " << std::dec << dvs_rd_ptr  << " ";
            // cout << "frame_num value (decimal): " << std::dec << frame_num << "(hex): 0x" << std::hex << frame_num << "  ";
            // cout << "timestamp value (decimal): " << std::dec << timestamp << "(hex): 0x" << std::hex << timestamp << endl;
            if ((prev_frame_num + 1 != frame_num) && (prev_frame_num != (frame_num + 255)))
            {
                if (!(check_init < 1000))
                {
                    error_num++;
                    std::cout << "ERROR NUM: " << error_num << endl;
                }
                else
                {
                    std::cout << "started..." << endl;
                }
            }
            prev_frame_num = frame_num;
            prev_timestamp = timestamp;

            if (dvs_rd_ptr == DVS_BUFFER_NUM - 1)
            {
                dvs_rd_ptr = 0;
            }
            else
            {
                dvs_rd_ptr++;
            }
        }
    }
}

// Mailbox<int> mailbox;
// bounding box shouldn' be implemented as mailbox structure.
// void *DVS_reader(void *arg)
// {
//     char *bin_name = ((char **)arg)[0];
//     char *video_name = ((char **)arg)[1];
//     int frame_width = *(int *)(((char **)arg)[2]);
//     int frame_height = *(int *)(((char **)arg)[3]);
//     int duration_secs = *(int *)(((char **)arg)[4]);
//     // OpenCV video writer object
//     VideoWriter video(video_name, VideoWriter::fourcc('a', 'v', 'c', '1'), SAVE_FPS, Size(frame_width, frame_height), false);
//     if (!video.isOpened())
//     {
//         cerr << "Error creating video file" << endl;
//         pthread_exit(NULL);
//     }

//     // Frame to hold DVS sensor data
//     Mat gray_frame(frame_height, frame_width, CV_8UC1, Scalar(0));
//     // namedWindow("DVS Camera", WINDOW_NORMAL);

//     // Buffer to read from .bin file
//     char *bin_read_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
//     ifstream file(bin_name, std::ios::binary);
//     if (!file.is_open())
//     {
//         cerr << "Failed to open file for reading." << endl;
//         pthread_exit(NULL);
//     }
//     file.seekg(0, ios::beg);

//     // Extracting frames from bin file
//     for (int t = 0; t < duration_secs * DISPLAY_FPS; t++)
//     {
//         for (int i = 0; i < DMA_BUFFER_GRP_NUM; i++)
//         {
//             file.read(bin_read_buffer, DVS_FRAME_SIZE);
//             if (i == 0)
//             {
//                 convert2BitTo8Bit(bin_read_buffer + 8, gray_frame.data, frame_width, frame_height);
//             }
//             else
//             {
//                 convert2BitTo8Bit_accum(bin_read_buffer + 8, gray_frame.data, frame_width, frame_height);
//             }
//         }
//         video.write(gray_frame);
//         pthread_mutex_lock(&display_mutex);

//         imshow("DVS camera", gray_frame);
//         if (waitKey(1) == 27)
//         { // Exit if ESC is pressed
//             pthread_mutex_unlock(&display_mutex);
//             break;
//         }
//         pthread_mutex_unlock(&display_mutex);
//     }

//     file.close();
//     free(bin_read_buffer);
//     destroyAllWindows();
//     video.release();
//     pthread_exit(NULL);
// }



void* DVS_reader_func(void *arg)
{
    ThreadArgs* args = (ThreadArgs*) arg;
    pcie_trans *trans = args->trans;
    char *dvs_buffer_1 = args->dvs_buffer_1;
    char *dvs_buffer_2 = args->dvs_buffer_2;
    // uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    // uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_rdy_addr= DVS_FRAME_RDY_BASEADDR;
    uintptr_t dvs_buffer_addr= DVS_FRAME_BASEADDR;
    int dvs_rd_ptr = 0;
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    // for (int i = 0; i < DVS_BUFFER_NUM; i++)
    // {
    //     dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
    //     dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    // }

    int prev_frame_num = -1;
    int check_init = 0;
    int error_num = 0;
    int double_buffer_idx = 0;
    char* dvs_buffer;
    while (1)
    {
        if(double_buffer_idx == 0){
            pthread_mutex_lock(&dvs_buffer_1_mutex);
            dvs_buffer = dvs_buffer_1;
        } else {
            pthread_mutex_lock(&dvs_buffer_2_mutex);
            dvs_buffer = dvs_buffer_2;
        }
        do{
            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr);//[dvs_rd_ptr]);
        }while((dvs_buffer_rdy[0] & 0x01) != 1); // buffer ready
            //
        read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr);//[dvs_rd_ptr]);
        write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr);//[dvs_rd_ptr]);
        int frame_num = static_cast<unsigned char>(dvs_buffer[4]);

        if ((prev_frame_num + 1 != frame_num) && (prev_frame_num != (frame_num + 255)))
        {
            error_num++;
            std::cout << "ERROR NUM: " << error_num << endl;
        } 
        prev_frame_num = frame_num;
        if(dvs_buffer_rdy_addr == DVS_FRAME_RDY_BASEADDR + DVS_BUFFER_NUM-1){
            dvs_buffer_rdy_addr = DVS_FRAME_RDY_BASEADDR;
            dvs_buffer_addr = DVS_FRAME_BASEADDR;
        }else{
            dvs_buffer_rdy_addr++;
            dvs_buffer_addr += DVS_FRAME_SIZE;
        }
        
        if(double_buffer_idx == 0){
            buffer_1_ready = true;
            pthread_cond_signal(&dvs_buffer_cond);
            pthread_mutex_unlock(&dvs_buffer_1_mutex);
            double_buffer_idx = 1;
        } else {
            buffer_2_ready = true;
            pthread_cond_signal(&dvs_buffer_cond);
            pthread_mutex_unlock(&dvs_buffer_2_mutex);
            double_buffer_idx = 0;
        }
        
    }

    free(dvs_buffer_rdy);
    free(dvs_buffer_done);
    return nullptr;
}

void* DVS_writer_func(void *arg)
{
    ThreadArgs* args = (ThreadArgs*) arg;
    char *dvs_buffer_1 = args->dvs_buffer_1;
    char *dvs_buffer_2 = args->dvs_buffer_2;

    char *bin_name = NULL;

    time_t current_time;
    struct tm *local_time;

    time(&current_time);
    local_time = localtime(&current_time);
    if (asprintf(&bin_name, "./bin_files/data_%04d-%02d-%02d_%02d-%02d-%02d.bin",
                 local_time->tm_year + 1900,
                 local_time->tm_mon + 1,
                 local_time->tm_mday,
                 local_time->tm_hour,
                 local_time->tm_min,
                 local_time->tm_sec) == -1)
    {
        perror("Error creating bin file name");
        return nullptr;
    }

    ofstream file(bin_name, ios::binary | ios::app);
    if (!file.is_open())
    {
        perror("Failed to open file for writing.");
        return nullptr;
    }

    while (1)
    {
        pthread_mutex_lock(&dvs_buffer_1_mutex);
        while(!buffer_1_ready){
            pthread_cond_wait(&dvs_buffer_cond, &dvs_buffer_1_mutex);
        }
        
        file.write(dvs_buffer_1, DVS_FRAME_SIZE ) ;
        buffer_1_ready = false;
        pthread_mutex_unlock(&dvs_buffer_1_mutex);
        pthread_mutex_lock(&dvs_buffer_2_mutex);
        while(!buffer_2_ready){
            pthread_cond_wait(&dvs_buffer_cond, &dvs_buffer_2_mutex);
        }
        
        file.write(dvs_buffer_2, DVS_FRAME_SIZE );
        buffer_2_ready = false;
        pthread_mutex_unlock(&dvs_buffer_2_mutex);
        
        
    }

    file.close();
    free(bin_name);
    return nullptr;
}

void *CIS_thread_func(void *args)
{
    pcie_trans *trans = (pcie_trans *)args;

    uintptr_t cis_buffer_rdy_addr[CIS_BUFFER_NUM];
    uintptr_t cis_buffer_addr[CIS_BUFFER_NUM];
    int cis_rd_ptr = 0;
    char *cis_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *cis_buffer_done = (char *)malloc(1 * sizeof(char));
    cis_buffer_done[0] = 0x00;

    for (int i = 0; i < CIS_BUFFER_NUM; i++)
    {
        cis_buffer_rdy_addr[i] = CIS_FRAME_RDY_BASEADDR + i;
        cis_buffer_addr[i] = CIS_FRAME_BASEADDR + ((CIS_FRAME_SIZE)*i);
    }

    while (1)
    {
        Mat CIS_frame = Mat::zeros(CIS_FRAME_H, CIS_FRAME_W, CV_8UC3);
        while (1)
        {
            read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, cis_buffer_rdy, 1, cis_buffer_rdy_addr[cis_rd_ptr]);
            if ((cis_buffer_rdy[0] & 0x01) == 1)
            {
                break;
            }
        }

        read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, (char *)CIS_frame.data, CIS_FRAME_SIZE, cis_buffer_addr[cis_rd_ptr]);
        write_from_buffer(trans->h2c_device_cis, trans->h2c_fd_cis, cis_buffer_done, 1, cis_buffer_rdy_addr[cis_rd_ptr]);

        // Lock the mutex before displaying the frame
        pthread_mutex_lock(&display_mutex);
        imshow("CIS camera", CIS_frame);
        if (waitKey(1) == 27)
        { // Exit if ESC is pressed
            pthread_mutex_unlock(&display_mutex);
            break;
        }
        pthread_mutex_unlock(&display_mutex);

        if (cis_rd_ptr == CIS_BUFFER_NUM - 1)
        {
            cis_rd_ptr = 0;
        }
        else
        {
            cis_rd_ptr++;
        }
    }

    free(cis_buffer_rdy);
    free(cis_buffer_done);
    return NULL;
}

void *DVS_thread_func(void *args)
{
    pcie_trans *trans = (pcie_trans *)args;

    uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    int dvs_rd_ptr = 0;
    char *dvs_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    for (int i = 0; i < DVS_BUFFER_NUM; i++)
    {
        dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
        dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    }

    while (1)
    {
        Mat DVS_frame = Mat::zeros(DVS_FRAME_H, DVS_FRAME_W, CV_8UC1);

        for (int dvs_frame_grp_num = 0; dvs_frame_grp_num < 20; dvs_frame_grp_num++)
        {
            while (1)
            {
                read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);
                if ((dvs_buffer_rdy[0] & 0x01) == 1)
                {
                    break;
                }
            }

            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr[dvs_rd_ptr]);
            write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);

            if (dvs_frame_grp_num == 0)
            {
                convert2BitTo8Bit(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            else
            {
                convert2BitTo8Bit_accum(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }

            if (dvs_rd_ptr == DVS_BUFFER_NUM - 1)
            {
                dvs_rd_ptr = 0;
            }
            else
            {
                dvs_rd_ptr++;
            }
        }

        // Lock the mutex before displaying the frame
        pthread_mutex_lock(&display_mutex);
        imshow("DVS camera", DVS_frame); // waitkey both threads might be bad...
        if (waitKey(1) == 27)
        { // Exit if ESC is pressed
            pthread_mutex_unlock(&display_mutex);
            break;
        }
        pthread_mutex_unlock(&display_mutex);
    }

    free(dvs_buffer);
    free(dvs_buffer_rdy);
    free(dvs_buffer_done);
    return NULL;
}

void CIS_DVS_stream(pcie_trans *trans)
{
    pthread_t CIS_thread, DVS_thread;

    // Create the CIS thread
    if (pthread_create(&CIS_thread, NULL, CIS_thread_func, (void *)trans))
    {
        fprintf(stderr, "Error creating CIS thread\n");
        return;
    }

    // Create the DVS thread
    if (pthread_create(&DVS_thread, NULL, DVS_thread_func, (void *)trans))
    {
        fprintf(stderr, "Error creating DVS thread\n");
        return;
    }

    // Wait for both threads to finish
    if (pthread_join(CIS_thread, NULL))
    {
        fprintf(stderr, "Error joining CIS thread\n");
        return;
    }

    if (pthread_join(DVS_thread, NULL))
    {
        fprintf(stderr, "Error joining DVS thread\n");
        return;
    }
} 

void DVS_threading(pcie_trans *trans)
{
    pthread_t DVS_writer, DVS_reader;
    char* dvs_buffer_1 = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char* dvs_buffer_2 = (char *)malloc(DVS_FRAME_SIZE *sizeof(char));
    ThreadArgs arg;
    arg.trans = trans;
    arg.dvs_buffer_1 = dvs_buffer_1; 
    arg.dvs_buffer_2 = dvs_buffer_2;
    // Create the CIS thread
    if (pthread_create(&DVS_reader, NULL, DVS_reader_func, (void *)(&arg)))
    {
        fprintf(stderr, "Error creating read thread\n");
        return;
    }

    // Create the DVS thread
    if (pthread_create(&DVS_writer, NULL, DVS_writer_func, (void *)(&arg)))
    {
        fprintf(stderr, "Error creating write thread\n");
        return;
    }

    // Wait for both threads to finish
    if (pthread_join(DVS_reader, NULL))
    {
        fprintf(stderr, "Error joining read thread\n");
        return;
    }

    if (pthread_join(DVS_writer, NULL))
    {
        fprintf(stderr, "Error joining write thread\n");
        return;
    }
    free(dvs_buffer_1);
    free(dvs_buffer_2);
}


void *DVS_crop_coord(void *args)
{
    pcie_trans *trans = (pcie_trans *)args;

    uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    int dvs_rd_ptr = 0;
    char *dvs_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    for (int i = 0; i < DVS_BUFFER_NUM; i++)
    {
        dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
        dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    }

    while (1)
    {
        Mat DVS_frame = Mat::zeros(DVS_FRAME_H, DVS_FRAME_W, CV_8UC1); 
        int *x_count = (int *)calloc(DVS_FRAME_W, sizeof(int)); 
        int *y_count = (int *)calloc(DVS_FRAME_H, sizeof(int));
        int sum = 0;
        for (int dvs_frame_grp_num = 0; dvs_frame_grp_num < DMA_BUFFER_GRP_NUM; dvs_frame_grp_num++)
        {
            while (1)
            {
                read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);
                if ((dvs_buffer_rdy[0] & 0x01) == 1)
                {
                    break;
                }
            }

            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr[dvs_rd_ptr]);
            write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);

            if (dvs_frame_grp_num == 0)
            {
                convert2BitTo8Bit(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            else
            {
                convert2BitTo8Bit_accum(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            sum += event_accum(dvs_buffer + FRAME_HEADER_BYTES, x_count, y_count, DVS_FRAME_W, DVS_FRAME_H);

            if (dvs_rd_ptr == DVS_BUFFER_NUM - 1)
            {
                dvs_rd_ptr = 0;
            }
            else
            {
                dvs_rd_ptr++;
            }
        }
        bbox b_box;
        event_roi(x_count, y_count, DVS_FRAME_W, DVS_FRAME_H, sum, ROI_THRESH, ROI_MIN_SIZE, ROI_INFLATION, &b_box);
        free(x_count);
        free(y_count);
        Point p1(b_box.lx, b_box.ly);
        Point p2(b_box.hx, b_box.hy);
        rectangle(DVS_frame, p1, p2, Scalar(255), 2, LINE_8);
        // Lock the mutex before displaying the frame
        pthread_mutex_lock(&display_mutex);
        imshow("DVS camera", DVS_frame); // waitkey both threads might be bad...
        if (waitKey(1) == 27)
        { // Exit if ESC is pressed
            pthread_mutex_unlock(&display_mutex);
            break;
        }
        pthread_mutex_unlock(&display_mutex);
    }

    free(dvs_buffer);
    free(dvs_buffer_rdy);
    free(dvs_buffer_done);
    return NULL;
}



void *DVS_bbox_thread_func(void *args)
{
    pcie_trans *trans = (pcie_trans *)args;

    uintptr_t dvs_buffer_rdy_addr[DVS_BUFFER_NUM];
    uintptr_t dvs_buffer_addr[DVS_BUFFER_NUM];
    int dvs_rd_ptr = 0;
    char *dvs_buffer = (char *)malloc(DVS_FRAME_SIZE * sizeof(char));
    char *dvs_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *dvs_buffer_done = (char *)malloc(1 * sizeof(char));
    dvs_buffer_done[0] = 0x00;

    for (int i = 0; i < DVS_BUFFER_NUM; i++)
    {
        dvs_buffer_rdy_addr[i] = DVS_FRAME_RDY_BASEADDR + i;
        dvs_buffer_addr[i] = DVS_FRAME_BASEADDR + ((DVS_FRAME_SIZE)*i);
    }

    while (1)
    {
        Mat DVS_frame = Mat::zeros(DVS_FRAME_H, DVS_FRAME_W, CV_8UC1); 
        int *x_count = (int *)calloc(DVS_FRAME_W, sizeof(int)); 
        int *y_count = (int *)calloc(DVS_FRAME_H, sizeof(int));
        int sum = 0;
        for (int dvs_frame_grp_num = 0; dvs_frame_grp_num < DMA_BUFFER_GRP_NUM; dvs_frame_grp_num++)
        {
            while (1)
            {
                read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer_rdy, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);
                if ((dvs_buffer_rdy[0] & 0x01) == 1)
                {
                    break;
                }
            }

            read_to_buffer(trans->c2h_device_dvs, trans->c2h_fd_dvs, dvs_buffer, DVS_FRAME_SIZE, dvs_buffer_addr[dvs_rd_ptr]);
            write_from_buffer(trans->h2c_device_dvs, trans->h2c_fd_dvs, dvs_buffer_done, 1, dvs_buffer_rdy_addr[dvs_rd_ptr]);

            if (dvs_frame_grp_num == 0)
            {
                convert2BitTo8Bit(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            else
            {
                convert2BitTo8Bit_accum(dvs_buffer + FRAME_HEADER_BYTES, DVS_frame.data, DVS_FRAME_W, DVS_FRAME_H);
            }
            sum += event_accum(dvs_buffer + FRAME_HEADER_BYTES, x_count, y_count, DVS_FRAME_W, DVS_FRAME_H);

            if (dvs_rd_ptr == DVS_BUFFER_NUM - 1)
            {
                dvs_rd_ptr = 0;
            }
            else
            {
                dvs_rd_ptr++;
            }
        }
        bbox b_box;
        int is_roi = event_roi(x_count, y_count, DVS_FRAME_W, DVS_FRAME_H, sum, ROI_THRESH, ROI_MIN_SIZE, ROI_INFLATION, &b_box);
        free(x_count);
        free(y_count);
        Point p1(b_box.lx, b_box.ly);
        Point p2(b_box.hx, b_box.hy);
        pthread_mutex_lock(&bbox_mutex);
        if(is_roi) {
            Bbox.lx = b_box.lx;
            Bbox.ly = b_box.ly;
            Bbox.hx = b_box.hx;
            Bbox.hy = b_box.hy;
        }
        bbox_ready = true;
        pthread_cond_signal(&bbox_cond);
        pthread_mutex_unlock(&bbox_mutex);
        rectangle(DVS_frame, p1, p2, Scalar(255), 2, LINE_8);
        // Lock the mutex before displaying the frame
        pthread_mutex_lock(&display_mutex);
        imshow("DVS camera", DVS_frame); // waitkey both threads might be bad...
        if (waitKey(1) == 27)
        { // Exit if ESC is pressed
            pthread_mutex_unlock(&display_mutex);
            break;
        }
        pthread_mutex_unlock(&display_mutex);
    }

    free(dvs_buffer);
    free(dvs_buffer_rdy);
    free(dvs_buffer_done);
    return NULL;
}

void *CIS_bbox_thread_func(void *args)
{
    pcie_trans *trans = (pcie_trans *)args;

    uintptr_t cis_buffer_rdy_addr[CIS_BUFFER_NUM];
    uintptr_t cis_buffer_addr[CIS_BUFFER_NUM];
    int cis_rd_ptr = 0;
    char *cis_buffer_rdy = (char *)malloc(1 * sizeof(char));
    char *cis_buffer_done = (char *)malloc(1 * sizeof(char));
    cis_buffer_done[0] = 0x00;

    for (int i = 0; i < CIS_BUFFER_NUM; i++)
    {
        cis_buffer_rdy_addr[i] = CIS_FRAME_RDY_BASEADDR + i;
        cis_buffer_addr[i] = CIS_FRAME_BASEADDR + ((CIS_FRAME_SIZE)*i);
    }

    while (1) 
    {
        Mat CIS_frame = Mat::zeros(CIS_FRAME_H, CIS_FRAME_W, CV_8UC3);
        while (1)
        {
            read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, cis_buffer_rdy, 1, cis_buffer_rdy_addr[cis_rd_ptr]);
            if ((cis_buffer_rdy[0] & 0x01) == 1)
            {
                break;
            }
        }

        read_to_buffer(trans->c2h_device_cis, trans->c2h_fd_cis, (char *)CIS_frame.data, CIS_FRAME_SIZE, cis_buffer_addr[cis_rd_ptr]);
        write_from_buffer(trans->h2c_device_cis, trans->h2c_fd_cis, cis_buffer_done, 1, cis_buffer_rdy_addr[cis_rd_ptr]);
        bbox b_box; 
        pthread_mutex_lock(&bbox_mutex);  
        while(!bbox_ready){
            pthread_cond_wait(&bbox_cond, &bbox_mutex);
        }
        b_box.lx = (CIS_DVS_SCALE_X * CIS_FRAME_H/DVS_FRAME_H)*Bbox.lx + CIS_DVS_OFFSET_X;
        b_box.ly = (CIS_DVS_SCALE_Y * CIS_FRAME_H/DVS_FRAME_H)*Bbox.ly + CIS_DVS_OFFSET_Y;
        b_box.hx = (CIS_DVS_SCALE_X * CIS_FRAME_H/DVS_FRAME_H)*Bbox.hx + CIS_DVS_OFFSET_X;
        b_box.hy = (CIS_DVS_SCALE_Y * CIS_FRAME_H/DVS_FRAME_H)*Bbox.hy + CIS_DVS_OFFSET_Y;
        bbox_ready = false;
        pthread_mutex_unlock(&bbox_mutex); 
        Point p1(b_box.lx, b_box.ly);
        Point p2(b_box.hx, b_box.hy);
        rectangle(CIS_frame, p1, p2, Scalar(255,0,0), 2, LINE_8);
        Point DVS_UL(CIS_DVS_OFFSET_X, CIS_DVS_OFFSET_Y);
        Point DVS_LR(CIS_DVS_OFFSET_X +(CIS_DVS_SCALE_X * CIS_FRAME_H *DVS_FRAME_W/ DVS_FRAME_H ),
                    CIS_DVS_OFFSET_Y+ (CIS_DVS_SCALE_Y * CIS_FRAME_H ));
        rectangle(CIS_frame,DVS_UL, DVS_LR, Scalar(0,255,0), 2, LINE_8);
        // Lock the mutex before displaying the frame
        pthread_mutex_lock(&display_mutex);
        imshow("CIS camera", CIS_frame); 
        if (waitKey(1) == 27) 
        { // Exit if ESC is pressed 
            pthread_mutex_unlock(&display_mutex);
            break;
        }
        pthread_mutex_unlock(&display_mutex);

        if (cis_rd_ptr == CIS_BUFFER_NUM - 1)
        {
            cis_rd_ptr = 0;
        }
        else
        {
            cis_rd_ptr++;
        }
    }

    free(cis_buffer_rdy);
    free(cis_buffer_done);
    return NULL;
}

void CIS_DVS_bbox_stream(pcie_trans *trans)
{
    pthread_t CIS_thread, DVS_thread;

    // Create the CIS thread
    if (pthread_create(&CIS_thread, NULL, CIS_bbox_thread_func, (void *)trans))
    {
        fprintf(stderr, "Error creating CIS thread\n");
        return;
    }

    // Create the DVS thread
    if (pthread_create(&DVS_thread, NULL, DVS_bbox_thread_func, (void *)trans))
    {
        fprintf(stderr, "Error creating DVS thread\n");
        return;
    }

    // Wait for both threads to finish
    if (pthread_join(CIS_thread, NULL))
    {
        fprintf(stderr, "Error joining CIS thread\n");
        return;
    }

    if (pthread_join(DVS_thread, NULL))
    {
        fprintf(stderr, "Error joining DVS thread\n");
        return;
    }
} 