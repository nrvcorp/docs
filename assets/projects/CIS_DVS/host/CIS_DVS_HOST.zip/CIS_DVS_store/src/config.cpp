#include <assert.h>
#include <fcntl.h>
#include <getopt.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <dirent.h>

#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/time.h>
#include <sys/types.h>
#include <unistd.h>
#include <pthread.h>
#include <png.h>
#include "config.hpp"


int configure (pcie_trans * trans) {
	/* CIS pcie setting*/
	trans->h2c_device_cis = H2C_DEVICE_CIS;
	trans->c2h_device_cis = C2H_DEVICE_CIS;
    /* check h2c functionality */
	trans->h2c_fd_cis = open(trans->h2c_device_cis, O_RDWR);
	if (trans->h2c_fd_cis < 0) {
		fprintf(stderr, "unable to open device %s, %d.\r\n", trans->h2c_device_cis, trans->h2c_fd_cis);
		perror("open device");
		return -EINVAL;
	}
	/* check c2h functionality */
	trans->c2h_fd_cis = open(trans->c2h_device_cis, O_RDWR);
	if (trans->c2h_fd_cis < 0) {
		fprintf(stderr, "unable to open device %s, %d.\r\n", trans->c2h_device_cis, trans->c2h_fd_cis);
		perror("open device");
		return -EINVAL;
	}


	/* DVS pcie setting*/
    trans->h2c_device_dvs = H2C_DEVICE_DVS;
    trans->c2h_device_dvs = C2H_DEVICE_DVS;


	/* check h2c functionality */
	trans->h2c_fd_dvs = open(trans->h2c_device_dvs, O_RDWR);
	if (trans->h2c_fd_dvs < 0) {
		fprintf(stderr, "unable to open device %s, %d.\r\n", trans->h2c_device_dvs, trans->h2c_fd_dvs);
		perror("open device");
		return -EINVAL;
	}
	/* check c2h functionality */
	trans->c2h_fd_dvs = open(trans->c2h_device_dvs, O_RDWR);
	if (trans->c2h_fd_dvs < 0) {
		fprintf(stderr, "unable to open device %s, %d.\r\n", trans->c2h_device_dvs, trans->c2h_fd_dvs);
		perror("open device");
		return -EINVAL;
	}

    // pcie_trans->reg_device = REG_DEVICE;
    // trans->user_device = USER_DEVICE;

	// trans->reg_fd = open(trans->reg_device, O_RDWR);
	// if (trans->reg_fd < 0) {
    //     fprintf(stderr, "unable to open device %s, %d.\n",
    //         trans->reg_device, trans->reg_fd);
    //     perror("open reg device failed");
    // }

	// trans->user_fd = open(trans->user_device, O_RDWR | O_SYNC);
	// if (trans->user_fd < 0) {
	// 	fprintf(stderr, "unable to open device %s, %d.\n",
    //         trans->user_device, trans->user_fd);
    //     perror("open USER device failed");
	// }

	// trans->map_base = mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, trans->reg_fd, 0);
	// if (trans->map_base == (void *)-1) {
	// 	printf("error unmap \r\n");
	// }

	// trans->user_base = mmap(0, MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, trans->user_fd, 0);
	// if (trans->user_base == (void *)-1) {
	// 	printf("error unmap \r\n");
	// }
}